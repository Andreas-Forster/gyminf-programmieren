public class Node {
    Node next; // Adresse des nächsten Elements
    int value; // Wert den wir in der Liste Speichern

    // Konstruktor um den Wert beim erstellen des Objekts zu setzen.
    Node(int v) {
        value = v;
    }

    // Einfügen eines Knotens am Ende der Liste
    void append(Node newNode) {
        Node current = this;
        while(current.next != null) { // solange wir nicht beim letzten Element sind
            current = current.next; // gehe ein Element weiter
        }
        current.next = newNode;
    }

    // rekursive version von append
    void appendRecursive(Node newNode) {
        if ( this.next == null) { // wenn wir beim letzten Element sind,
            this.next = newNode; // wir hängen das Element an
        } else {
            this.next.appendRecursive(newNode); // wenn wir nicht beim letzten Element sind, dann hängen wir das neue Element an das nächste Element an
        }
    }

    // Ausgeben der Liste
    static void print(Node n) {
        Node current = n; // starten mit dem ersten Element
        while(current != null) { // solange das Element ein Objekt ist, also nicht null
            System.out.println(current.value);
            current = current.next; // zum nächsten Element gehen
        }
    }

    // rekursive ausgabe der Liste
    void printRecursive() {
        System.out.println(value); // gib den aktuellen Wert aus
        if (next != null) { // wenn wir noch nicht beim letzten Element sind,
            next.printRecursive(); // schreib das nächste Element raus
        }
    }
}