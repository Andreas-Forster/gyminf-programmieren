public class App {
    public static void main(String[] args) {
        Node first = new Node(4);

        //System.out.println(first.value);
        //Node second = new Node(2);
        //first.next = second;
        //System.out.println(second);
        //first.next = new Node(7);
        //first.next.next = new Node(9);

        Node newNode = new Node(17);
        first.append(newNode);


        first.append(new Node(23));
        first.append(new Node(32));
        first.append(new Node(42));
        first.append(new Node(7));

        //for( int i = 0; i<99; i += 1) {
        //    first.append(new Node(i));
        //}
        
        //System.out.println(first.value);
        //System.out.println(first.next.value);
        Node.print(first);
        System.out.println();
        first.printRecursive();
    }
    
}
