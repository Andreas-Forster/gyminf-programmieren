public class Factory {

    // Das Programm welches die Klasse TeslaModel3 benutzt.
    public static void main(String[] args) {
        TeslaModel3 tesla = new TeslaModel3();
    }
    
}
