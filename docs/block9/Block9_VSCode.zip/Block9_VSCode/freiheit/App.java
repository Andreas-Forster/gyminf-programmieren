public class App {

    // Verwenden der Kommandozeilenparameter
    // java App wort1 wort2 wort3 97
    public static void main(String[] args) {
        // Alle Elemente sind Strings, als String können Sie direkt verwendet werden
        System.out.println(args[0]); // wort1
        System.out.println(args[1]); // wort2
        System.out.println(args[2]); // wort3

        // Zahlen müssen aus dem String umgewandelt werden (gibts auch für Double oder Float)
        int input = Integer.parseInt(args[3]); // 97
        System.out.println(input);
    }
}