public class App2 {

    // Die Mathematik dahinter:
    // 1! = 1 // Abbruchbedingung
    // n! = n * (n-1)!
    // f(n) = n * f(n-1)   // kann direkt im Code umgesetzt werden
    // n! = n * (n-1) * (n-2)

    // rekursive Methode
    int factorial(int n) {
        System.out.println("Aufruf mit: " + n); // Debuggin Output
        if( n == 1 ) { // Abbruch bedingung
            return 1;
        }
        return  n * factorial(n-1); // rekursiver Aufruf 
    }


    // java App 5
    public static void main(String[] args) {
        int input = 5; //Integer.parseInt(args[0]); // Für das Debuggen verwenden wir einen fixen Wert
        App2 app = new App2();
        System.out.println("Resultat: "+app.factorial(input));
    }
}
