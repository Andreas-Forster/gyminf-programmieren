public class TeslaModel3 {
    // Werte die für jedes Objekt dieser Klasse gelten
    static int existingCars = 0;
    static int ps = 183;
    static String modelName = "Tesla Model 3";

    // Eigenschaften oder Werte die für jedes Objekt gespeichert werden sollen
    int fahrgestellNr;
    boolean engineRunning = false;

    // methode um ein Objekt zu verändern
    void switchEngine() {
        engineRunning = !engineRunning;
        //return engineRunning;
    }
    
    // abfrage eines Zustands eines Objekts
    boolean getEngineIsRunning() {
        return engineRunning;
    }

    // verändert die Klasse / alle Objekte 
    static void update(int powerGain) {
        ps += powerGain;
    }

    // Konstruktor um die Werte für ein Objekt auf sinnvolle Werte zu setzen
    // sowie Klassen spezifische Änderungen.
    TeslaModel3() {
        existingCars += 1;
        this.fahrgestellNr = existingCars;
        // int identification = existingCars; // existiert nur im Konstruktor
    }

    // Konstruktor welcher mit einem Parameter gesteurt werden kann
    TeslaModel3(int number) {
        existingCars += 1;
        this.fahrgestellNr = number;
        // int identification = existingCars; // existiert nur im Konstruktor
    }


}
