public class MyApp {
    
    public static void main( String[] args) {
        Rezept rezept = new Rezept();
        rezept.zutat = new Zutat("Birnen",7);
        rezept.zubereitungsZeit = 60;
        System.out.println("Benoetigt\n"+rezept.zutat+"\n Zeit: "+rezept.zubereitungsZeit);
    }
}
