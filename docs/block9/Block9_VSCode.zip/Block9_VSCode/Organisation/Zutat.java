class Zutat {
    String name; // name
    double menge; // menge

    Zutat(String einName, double menge) {
        this.name = einName;
        this.menge = menge;
    }

    @Override
    public String toString() {
        return this.name + ": " + this.menge;
    }

}