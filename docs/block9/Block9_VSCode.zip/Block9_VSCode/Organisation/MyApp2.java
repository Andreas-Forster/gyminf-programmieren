public class MyApp2 {
    
    public static void main(String[] args) {
        Zutat apfel = new Zutat("Apfel", 3); // neues Objekt
        //apfel.name = "Apfel";
        //apfel.menge = 3; // setzen von Werten
        //System.out.println(apfel.name + ": " + apfel.menge);// Ausgabe auf Konsole
        System.out.println(apfel);
    }
    
}
