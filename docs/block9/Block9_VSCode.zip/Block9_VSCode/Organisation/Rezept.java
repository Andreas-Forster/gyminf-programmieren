public class Rezept {
    Zutat z1;
    int zubereitungsZeit;
}
