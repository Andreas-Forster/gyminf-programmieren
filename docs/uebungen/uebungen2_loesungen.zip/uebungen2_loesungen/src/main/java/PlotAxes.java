import static ch.unibas.informatik.jturtle.TurtleCommands.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

class PlotAxes {

  // Definieren Sie hier alle Felder die Sie benoetigen.
  Point origin; // Koordinatenursprung / Schnittpunkt der Achsen
  double lenX; // Laenge der x-Achse
  double lenY; // Laenge der y-Achse

  /**
   * Kreiert ein Objekt der Klasse PlotAxes, welches durch den Koordinatenursprung
   * (also den Punkt unten Links) sowie die Laengen der x und y-Achse definiert
   * ist.
   */
  PlotAxes(Point origin, double lengthXAxis, double lengthYAxis) {
    this.origin = origin; // Parameter und Objekt-Variable haben den selben Namen, verwenden von this
    lenX = lengthXAxis; // anderer Name, this kann weggelassen werden
    lenY = lengthYAxis;
  }

  /**
   * Diese Methode nutzt das als Argument uebergebene Turtle um die
   * Koordinatenachsen an der vorgegebenen Position zu zeichnen. Nutzen Sie die
   * statische Methode TurtleUtils.setTurtlePosition um das Turtle an die richtige
   * Position zu setzen.
   */
  void drawWithTurtle() {
    // wir gehen ohne zu zeichnen an den Koordinatenursprung
    penUp();
    TurtleUtils.setTurtlePosition(origin);

    penDown(); // jetzt beginnen wir zu zeichnen, die Turtle schaut nach oben (y-Achse)
    // zeichnet die y-Achse laeuft zurueck
    forward(lenY);
    backward(lenY);
    // um die x-Achse zu zeichnen, drehen wir uns zuerst um 90 Grad
    turnRight(90);
    forward(lenX);
    // und gehen dann zurueck in die Ausgangs-Position und Orientierung
    backward(lenX);
    turnRight(-90);

  }

  /**
   * Einfaches Testprogramm um Ihre Zeichnung zu testen
   */
  public static void main(String[] args) {
    home();
    clear();
    PlotAxes pa = new PlotAxes(new Point(-30, -50), 60, 100);
    pa.drawWithTurtle();

    BufferedImage img = drawing();

    try {
      ImageIO.write(img, "png", new java.io.File("axes.png"));
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
  }

}