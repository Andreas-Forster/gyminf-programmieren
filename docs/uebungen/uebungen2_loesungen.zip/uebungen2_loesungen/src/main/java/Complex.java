class Complex {

  double real;
  double imag;

  /**
   * Erstellt eine neue Komplexe Zahl mit gegebenem
   * Real- und Imaginärteil.
   */
  Complex(double real, double imag) {
    // da die Namen identisch sind, müssen wir this verwenden.
    this.real = real;
    this.imag = imag;
  }

  /**
   * Addiert die Komplexe Zahl other mit der durch dieses
   * Objekt repräsentierten Komplexe Zahl. Das Ergebnis
   * wir als neue Komplexe Zahl zurückgegeben.
   */
  public Complex add(Complex other) {
    // Addition nach der Regel R1+R2, I1+I2
    return new Complex(this.real+other.real,this.imag + other.imag);
  }

  /* Addiert die Komplexe Zahl other mit der durch dieses
   * Objekt repräsentierten Komplexen Zahl. Nach diese
   * Operation soll das aktuelle Objekt der Addition beider
   * Zahlen entsprechen.
   */
  public void addInplace(Complex other) {
    // Addition inplace ist unproblematisch.
    this.real += other.real;
    this.imag += other.imag;
  }

  /**
   * Multipliziert die Komplexe Zahl other mit der durch dieses
   * Objekt repräsentierten Komplexen Zahl. Das Ergebnis wird
   * als neue Komplexe Zahl zurückgegeben.
   */
  Complex multiply(Complex other) {
    // Multiplikation nach der Regel
    // R1*R2 - I1*I2
    // R1*I2 + I1*R2
    return new Complex(
      this.real * other.real - this.imag * other.imag,
      this.real * other.imag + this.imag * other.real);
  }

  /**
   * Multipliziert die Komplexe Zahl other mit der durch dieses
   * Objekt repräsentierten Komplexen Zahl. Nach dieser
   * Operation soll das aktuelle Objekt der Multiplikation beider
   * Zahlen entsprechen.
   */
  void multiplyInplace(Complex other) {
     
    // Bei der inplace Multiplikation müssen wir aufpassen,
    // dass wir das Objekt nicht zu früh verändern und in der
    // zweiten Berechnung schon den veränderten Wert verwenden.
    double tmp = this.real * other.real - this.imag * other.imag; // speichert das Resultat zwischen
    this.imag = this.real * other.imag + this.imag * other.real;
    this.real = tmp; // Zuweisung des zwischengespeicherten Resultats
  }


  /**
   * Gibt den Absolutwert der Komplexen Zahl zurück
   */
  public double abs() {
    // Berechnung des Betrags der Zahl (wie bei einem Vektor)
    // sqrt(R*R + I*I)
    return Math.sqrt(real*real+imag*imag);
  }

}