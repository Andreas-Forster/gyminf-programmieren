import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Dieses Objekt fast alle Relevanten Daten zu einer Berechnung vom
 * der Mandelbrotmenge.
 */
class MandelbrotResult {

  int maxIterations;
  int numberOfIterationsUntilEscaped;
  Complex number;

  /**
   * Kreiert ein neues MandelbrotResult. Es werden folgende Daten gespeichert:
   * - maximalen Anzahl Iterationen (maxIterations),
   * - Fluchtgeschwindigkeit (numberOfIterationsUntilEscaped),
   * - die aus der berechneten Folge resultierende Komplexe Zahl (number)
   */
  MandelbrotResult(int maxIterations, int numberOfIterationsComputed, Complex number) {
    this.maxIterations = maxIterations;
    this.numberOfIterationsUntilEscaped = numberOfIterationsComputed;
    this.number = number;
  }

  /**
   * Gibt an ob die Folge konvergiert ist
   */
  boolean hasEscaped() {
    return numberOfIterationsUntilEscaped < maxIterations;
  }
}

/**
 * Diese Klasse enthaelt Methoden zur Berechnung und Visualisierung
 * der Mandelbrotmenge.
 */
class Mandelbrot {

  // Groesse des Bild, das visualisiert wird
  static final int IMAGE_WIDTH =  600;
  static final int IMAGE_HEIGHT = 600;

  // Felder die zur Visualisierung verwendet werden.
  BufferedImage image =  new BufferedImage(
      IMAGE_WIDTH,
      IMAGE_HEIGHT,
      BufferedImage.TYPE_INT_ARGB
  );


  /**
   * Speichert das erzeugte Bild unter angegebenem Dateinamen
   */
  public void save(String filename) {
    try {
      ImageIO.write(this.image, "png", new java.io.File(filename));
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }
  }

  /**
   * Setzt Pixel mit index (i, j) auf die angegebene Farbe
   */
  private void setPixel( int i, int j, java.awt.Color color) {
    image.setRGB(i, j, color.getRGB());
  }

  /**
   * Berechnet die Mandelbrot-folge c_1, ... c_n, fuer eine gegebene Komplexe Zahl c.
   * Die Folge wird berechnet bis entweder abs(c_i) > 2 gilt oder die Anzahl
   * iterationen erreicht wurde.
   */
  MandelbrotResult computeMandelbrot(Complex c, int maxIterations) {
    
    // Aus der Aufgabenstellung, wir beginnen mit der (0,0) als Startwert.
    Complex zn = new Complex(0,0);

    // Zaehler fuer die benoetigten Iterationen
    int cnt = 0;
    
    // Solange wir nicht maxIterations berechnet haben oder
    // die aktuelle Zahl zn einen groesseren Betrag als 2.0 hat
    while (cnt < maxIterations && !(zn.abs()>2.0)) {

      // berechnen von zn+1 = zn^2 + c
      // als zn+1 = zn * zn + c
      zn.multiplyInplace(zn);
      zn.addInplace(c);

      // eine Iteration ist durch, wir erhoehen den Zaehler
      cnt+= 1;
    }

    // Wir geben ein neues Objekt MandelbrotResult zurueck mit den Werten.
    return new MandelbrotResult(maxIterations,cnt,zn);
  }

  /**
   * Wandelt ein pixel index gegeben durch i und j in eine Komplexe Zahl um.
   * Dabei soll der realanteil i * scaling + panX sein und der
   * Imaginaeranteil j * scaling + panY.
   */
  Complex pixelPosToComplexNumber(int i, int j, 
                                  double scaling, double panX, double panY) {
    // Erstellen einer neuen Komplexen Zahl nach der Vorschrift.
    return new Complex(i*scaling+panX,j*scaling+panY);
  }

  /**
    * Kreiert eine Visualisierung der Mandelbrotmenge. Dabei werden alle Pixel des Bildes
   *  this.image entsprechend dem Resultat der Mehode computeMandelBrot eingefaerbt.
   *  Die jeweilige Bildkoordinate wird mit der Methode pixelPosToComplexNumber in
   *  eine Komplexe Zahl umgewandet.
   *
   *  Zur visualisieren werden die Methoden setPixel und ColorPalette.getColor benutzt.
   *
   */
  void createMandelbrotVisualization(double scaling, 
                                     double panX, double panY, int maxIterations) {
        // Wir laufen ueber alle x,y Positionen
        for( int x = 0; x<IMAGE_WIDTH; x++) {
          for( int y = 0; y<IMAGE_HEIGHT; y++) {
            // Berechnen der komplexen Zahl c fuer den Startwert.
            Complex c = pixelPosToComplexNumber(x, y, scaling, panX, panY);

            // Berechnen der Mandelbrotfolge mit c als Startwert.
            MandelbrotResult result = computeMandelbrot(c, maxIterations);

            // Berechnen der Farbe fuer das result mit Hilfe der ColorPalette.
            Color color = ColorPalette.getColor(result);
            
            // Wenn Sie die folgende Zeile einkommentieren, dann wird das bild in Graustufen gezeichnet.
            //color = ColorPalette.colorToGreyscale(color);

            // Setzen der Farbe an der richtigen Stelle.
            setPixel(x,y,color);
          }
        }
    // ihr Code
  }


  public static void main(String[] args) {
    // Erstellen eines neuen Mandelbrotes.
    Mandelbrot mb = new Mandelbrot();

    // berechnet ein Bild oder rechnet eine pseudo Animation (Bild wird oft berechnet und jeweils ueberschrieben)
    boolean animatedVersion = false;

    if (!animatedVersion) {

      // Aufruf zum zeichnen von einem Bild
      mb.createMandelbrotVisualization(
          0.004,
          -1.7,
          -1.2,
          100
      );

    } else {

      // Aufruf zum zeichnen in einer Schlaufe fuer andere Anfangswerte
      for ( double d = 0.004; d > 1e-10; d *= 0.9){
        System.out.println("calculate image for the scaling value: "+d);
        mb.createMandelbrotVisualization(
            d,
            -0.604894,
            -0.614894,
            100
        );
        mb.save("mandelbrot.png");

        // Den folgenden Code muessen Sie nicht komplett verstehen.
        // Er verwendet Exceptions (Ausnahmebehandlungen), was nicht Teil dieser Vorlesung war.
        // Das Programm soll eine Pause machen nach dem Zeichnen.

        // try bedeutet wir versuchen den folgenden Block auszufuehren,
        // sind uns aber bewusst, dass ein Fehler auftreten kann
        try { 
          int milliSeconds = 100;
          Thread.sleep(milliSeconds);

        // catch bedeutet, dass im Falle das ein Fehler aufgetreten ist
        // nehmen wir den Fehler (Exception) und versuchen den Fehler zu behandeln
        } catch (Exception e) {

          // Wenn ein Fehler aufgetreten ist,
          // geben wir einfach die Fehlermeldung aus
          // und machen dann normal weiter.
          System.out.println(e.getMessage());
        }

      }

    }
  }
}