import static ch.unibas.informatik.jturtle.TurtleCommands.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

class Rectangle {

  // Definieren Sie hier alle Felder die Sie benoetigen.
  Point llc; // linker unterer Eckpunkt
  double w; // Breite
  double h; // Hoehe

  /**
   * Kreiert ein neues Rectangle Objekt, welches ein Rechteck durch den unteren
   * Linken Punkt, sowie dessen Breite und Hoehe definiert.
   */
  Rectangle(Point lowerLeftCorner, double width, double height) {
    // zuweisen der Parameter an die Objekt-Variablen/Felder
    llc = lowerLeftCorner;
    w = width;
    h = height;
  }

  /**
   * Diese Methode nutzt das als Argument uebergebene Turtle um das Rechteck an der
   * vorgegebenen Position zu zeichnen. Nutzen Sie die statische Methode
   * TurtleUtils.setTurtlePosition um das Turtle an die richtige Position zu
   * setzen.
   */
  void drawWithTurtle() {
    // wir gehen ohne zu zeichnen an die Stelle des bekannten Eckpunktes
    penUp();
    TurtleUtils.setTurtlePosition(llc);

    // zeichen des Rechteckes, wir gehen zuerst nach oben und dann im Uhrzeigersinn um das Rechteck
    penDown();
    forward(h);
    turnRight(90);
    forward(w);
    turnRight(90);
    forward(h);
    turnRight(90);
    forward(w);
    turnRight(90);
  }

    /**
     * Einfaches Testprogramm um Ihre Zeichnung zu testen
     */
    public static void main(String[] args) {
      clear();
      home();

      Rectangle rect = new Rectangle(new Point(-30, -50), 60, 100);
      rect.drawWithTurtle();

      BufferedImage img = drawing();

      try {
        ImageIO.write(img, "png", new java.io.File("rectangle.png"));
      } catch (IOException e) {
        System.err.println(e.getMessage());
      }
  }
}
