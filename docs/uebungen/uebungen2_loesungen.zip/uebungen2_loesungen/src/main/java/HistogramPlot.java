import static ch.unibas.informatik.jturtle.TurtleCommands.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

class HistogramPlot {

    static final double PLOT_WIDTH = 100;
    static final double PLOT_HEIGHT = 100;
    static final Point LOWER_LEFT_CORNER_POINT = new Point(-50, -50);
  

    // definieren Sie hier alle benoetigten Felder
    Histogram hist; // speichert das Histogram
    int maxCount; // speichert die maximalen Werte pro Bin
    double scaling; // berechnet eine Skalierungsfaktor um die Anzahl Werte pro Bin in die Hoehe umzurechnen.
    double binWidth; // die breite des Bins

    /**
     * Kreiert ein neues HistogramPlot Objekt, welches ein Histogram 
     * mit numberOfBin Klassen der gegebenen Daten repraesentiert, 
     */
    HistogramPlot(double[] data, int numberOfBins) {
      // speichern der Daten als Histogram
      this.hist = new Histogram(data, numberOfBins);

      // wir suchen das Bin mit den meisten Werten
      maxCount = 0;
      for (int i = 0; i<hist.getNumberOfBins(); i++) {
        if(maxCount<hist.getNumberOfEntriesInBin(i)) {
          maxCount = hist.getNumberOfEntriesInBin(i);
        }
      }
      
      // die Skalierung ist die Plothoehe durch die maximale Anzahl der Werte pro Bin
      scaling = PLOT_HEIGHT/ (double) maxCount;

      // die Breite eines Bins ist die Breite des Plots geteilt durch die Anzahl Bins
      binWidth = PLOT_WIDTH / (double) hist.getNumberOfBins();
    }
  
  
    /**
     * Diese Methode nutzt ein gegebenes Turtle Objekt um das Histogram zu zeichnen. 
     * Dabei sollen die Klassen PlotAxes und Rectangle benutzt werden um die einzelnen
     * Elemente zu zeichnen. Die Laenge und Breite der Achsen ist dabei durch die 
     * vordefinierten Konstanten PLOT_WIDTH und PLOT_HEIGHT festgelegt.
     * Die Breite jedes Balkens soll entsprechend der Anzahl Klassen im Histogram 
     * festgelegt werden. 
     * Die Hoehe des Balkens soll proportional zu den Anzahl Eintraegen in jeder Histogram
     * Klasse sein. Dabei soll der hoechste Balken genau der Hoehe des Plots (PLOT_HEIGHT)
     * entsprechen. 
     */
    void drawWithTurtle() {
  
        // Wir erstellen die Achsen und zeichnen diese
        PlotAxes axis = new PlotAxes(LOWER_LEFT_CORNER_POINT, PLOT_WIDTH, PLOT_HEIGHT);
        axis.drawWithTurtle();

        // wir erstellen pro Balken im Diagramm ein Rechteck und zeichnen dieses.
        for (int i = 0; i<hist.getNumberOfBins(); i++) {

          // wir berechnen den unteren linken Eckpunkt
          Point llcpBin = new Point(
            LOWER_LEFT_CORNER_POINT.getX() + i * binWidth, // verschiebt sich immer um die Binbreite mal den Binindex
            LOWER_LEFT_CORNER_POINT.getY() // immer die gleiche Position unten
          );

          // erstellen und zeichnen des Rechtecks
          Rectangle rect = new Rectangle(llcpBin,binWidth,
            hist.getNumberOfEntriesInBin(i)*scaling // berechnen der Hoehe als Anzahl Eintraege mal Skalierung
          );
          rect.drawWithTurtle();
        }
    }
  
    /**
     * Kreiert und speichert ein Bild des Histogramplots unter angegebenem Dateinamen.
     */
    void saveToImage(String filename) {
      clear();
      penUp();
      home();
      drawWithTurtle();
      BufferedImage img  = drawing();
  
      try {
        ImageIO.write(img, "png", new java.io.File(filename));
      } catch (IOException e) {
        System.err.println(e.getMessage());
      }
    }
  
  
  
    public static void main(String[] args) throws Exception {
  
      // Einfacher Testcode. Gut zum Debuggen
      double[] simpleData = {1, 2, 2.1, 2, 4, 2.3, 4.1, 4.2, 3, 4, 4.1, 7, 7.1};
      HistogramPlot simplePlot = new HistogramPlot(simpleData, 7);
      simplePlot.saveToImage("./histogram-simple.png");
  

      // Etwas komplexerer Testcase. Hier wird ein Zufallsgenerator 
      // genutzt um 1000 Normalverteilte Zufallszahlen zu generieren.
      java.util.Random rng = new java.util.Random(42); // erstellt Zufallszahlengenerator
      double[] normalData = new double[1000];
      for (int i = 0; i < normalData.length; i++) {
        normalData[i] = rng.nextGaussian(); // erstellt eine neue Zufallszahl von einer Gauss'schen Verteilung
      }
      HistogramPlot normalPlot = new HistogramPlot(normalData, 30);
      normalPlot.saveToImage("./histogram-normal.png");
      

    }
  }