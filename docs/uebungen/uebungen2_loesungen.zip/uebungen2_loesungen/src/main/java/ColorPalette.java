import java.awt.*;

/**
 * Hilfsklasse, welche Methoden zur Verfügung stellt, um den Resultaten
 * aus der Mandelbrot-Berechnungen eine Farbe zuzuordnen.
 */
class ColorPalette {

  /** 
   * Nimmt ein Resultat der Mandelbrot Berechnung und gibt eine 
   * daraus berechnete Farbe zurück.
   */
  static Color getColor(MandelbrotResult result) {

    float brightness;
    if (result.hasEscaped())  {
      brightness = 1.0f;
    } else {
      brightness = 0.0f;
    }

    double nsmooth = (result.numberOfIterationsUntilEscaped + 1)
        - (Math.log(Math.log(result.number.abs())) / Math.log(2.0));


    return new Color(Color.HSBtoRGB((float) nsmooth / (float) (result.maxIterations),
        1.0f, brightness));
  }

  /** 
   * Nimmt eine Farbe und wandelt die gegebenen Farbe in einen Grauwert um.
   */
  static Color colorToGreyscale(Color color) {
    
    // Gewichtete Summe der Farbwerte von color.
    // Hier verwenden wir float, da die Color-Klasse float verlangt.
    float grayValue = (
      color.getRed()*0.2989f +
      color.getGreen()*0.5870f +
      color.getBlue()*0.1140f
    );
    
    // Erstellen einer neuen Farbe mit dem Grauwert für alle 3 Farben.
    // Parameter müssen vom Typ float oder int sein.
    // ACHTUNG: Bei Float ist der Wertebereich zwischen 0.0f und 1.0f, bei int jedoch zwischen 0 und 255.
    // HINWEIS: Alternativ zur Division mit 255 könnte man auch grayValue wider zu einem int machen.
    return new Color(grayValue/255,grayValue/255,grayValue/255);
    //return new Color((int)grayValue,(int)grayValue,(int)grayValue);
  }

  public static void main(String[] args) {
    Color color2 = ColorPalette.colorToGreyscale(new Color(100, 200, 150));
  }
}
