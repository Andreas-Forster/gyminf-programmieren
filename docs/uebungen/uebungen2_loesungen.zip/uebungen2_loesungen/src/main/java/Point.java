
class Point {
    
    // Definieren Sie hier alle Felder die Sie benoetigen.
    double x; // x Koordinate
    double y; // y Koordinate

    /**
     * Erzeugt ein neues Objekt mit den Koordinaten x und y
     */
    Point(double x, double y) {
        // Zuweisung mit this weil gleicher Name (Parameter/Objekt-Variable)
        this.x = x;
        this.y = y;
    }

    /**
     * Gibt die x-Koordinate zurueck
     */
    double getX() {
        // wir geben den Wert der Objekt-Variable zurueck
        return x;
    }

    /**
     * Gibt die y-Koordinate zurueck
     */
    double getY() {
        // analog zu getX
        return y;
    }

    public static void main(String[] args) {
        // wir erstellen zwei Objekte/Instanzen der Klasse Point
        Point p1 = new Point(1.0,2.0);
        Point p2 = new Point(-3.0,5.0);

        // wir geben die Koordinaten der Punkte aus
        System.out.println("p1: ("+p1.getX()+","+p1.getY()+")");
        System.out.println("p2: ("+p2.getX()+","+p2.getY()+")");
    }

}
