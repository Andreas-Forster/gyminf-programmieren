class Histogram {

  // Felder um die Daten sowie die Anzahl Bins zu speichern
  double[] data = null;
  int numberOfBins;

  /**
   * Erzeugt ein Histogram Objekt fuer die uebergebenen Gleitkommazahlen (daten),
   * mit den angegebenen anzahl Klassen (bins). Die Daten sollen in einem Feld
   * data und die anzahl Klassen in einem Feld numberOfBins gespeichert.
   */
  Histogram(double[] data, int numberOfBins) {
    this.data = data;
    this.numberOfBins = numberOfBins;
  }

  /**
   * Gibt die Anzahl Klassen (bins) zurueck
   */
  int getNumberOfBins() {
    return this.numberOfBins;
  }

  /*
   * gibt die im Histogram gespeicherten Daten zurueck
   */
  double[] getData() {
    return this.data;
  }

  /**
   * Gibt die Groesse einer Klasse (also das Interval zurueck). Die Intervallgroesse
   * berechnet sich als (max - min) / #bins, wobei max der Maximalwert in den
   * Daten ist, min der MinimalWert und #bins die Anzahl klassen.
   */
  public double getBinSize() {
    // wir verwenden die Funktionen welche das Maximum und Minimum zurueck geben
    // Es werden double Werte zurueck gegeben uns so muessen wir bei der Division nicht aufpassen.
    return (getMaxValue() - getMinValue()) / numberOfBins;
  }

  /**
   * Gibt den kleinsten Wert in den Daten zurueck
   */
  public double getMinValue() {
    // Wir starten mit dem groessten, darstellbaren Wert von Double.
    // Alternative: Wir k�nnten auch einfach mit dem ersten Element von data starten.
    double min = Double.MAX_VALUE;

    // wir laufen ueber alle elemente der Daten
    for (int i = 0; i<data.length; i++) {
      // wenn das aktuelle Element kleiner ist als das bisherige Minimum muessen wir was tun
      if (min > data[i]){
        // wir ersetzen das aktuelle Minimum mit dem neuen kleinsten Wert
        min = data[i];
      }
    }
    // wir geben das gefundene Minimum zurueck
    return min;
  }

  /**
   * Gibt den groessten Wert in den Daten zurueck
   */
  public double getMaxValue() {
    // analog zu getMinValue mit umgedrehter Bedingung beim if.
    double max = Double.MIN_VALUE;
    for (int i = 0; i<data.length; i++) {
      if (max < data[i]){
        max = data[i];
      }
    }
    return max;
  }


  /**
   * Gibt fuer eine gegebene Klasse (bestimmt durch binNumber) die Anzahl
   * Datenelemente zurueck die in diese Klasse fallen. Wir beginnen bei 0 zu
   * zaehlen. Das erste Bin hat also den index 0. Der groesste Wert faellt in den
   * letzten Bin
   * 
   * Beispiel: Angenommen wir haetten die Daten [4.1, 1.5, 5.0, 1.0, 3.0, 3.5, 4.0,
   * 3.1] und 4 bins. Dann waere getNumberOfEntriesInBin(0) = 2 (naemlich 1.0 und
   * 1.5) getNumberOfEntriesInBin(1) = 0 getNumberOfEntriesInBin(2) = 3 (naemlich
   * 3.0, 3.1, 3.5) getNumberOfEntriesInBin(3) = 3 (naemlich 4.0, 4.1, 5.0)
   * 
   * Beachten Sie, dass das letzte Bin speziell behandelt werden muss, da es
   * zusaetzlich auch das maximale Element beinhaltet
   */
  public int getNumberOfEntriesInBin(int binNumber) {
   double binSize = getBinSize(); // berechnen der binSize
   double lower = getMinValue() + binNumber * binSize; // berechnen der unteren Grenze des Bins
   double upper = getMinValue() + (binNumber + 1) * binSize; // berechnen der oberen Grenze des Bins
   int cnt = 0; // Zaehler fuer die Werte die in das Bin fallen

   // wir schauen uns alle elemente von data an
   for (int i = 0; i<data.length; i++) {

     double value = data[i]; // Zwischenspeichern des Wertes aus dem Array
     boolean fulfillsLowerBound = value >= lower; // boolean ob der Wert groesser oder gleich der Untergrenze
     boolean isLast = binNumber == (numberOfBins-1); // testen ob wir das letzte Bin behandeln
     boolean fulfillsUpperBound; // Platz fuer den boolean ob der Wert kleiner ist als die Obergrenze
     if (isLast) {
       fulfillsUpperBound = value <= upper; // wenn wir das letzte Bin anschauen, dann gehoert die Obergrenze dazu
     } else {
       fulfillsUpperBound = value < upper; // wenn wir nicht im letzten Bin sind, dann gehoert die Obergrenze nicht dazu (schon zum naechsten Bin)
     }

     if (  fulfillsLowerBound && fulfillsUpperBound ) {
       cnt += 1; // wenn beide Grenzbedingungen erfuellt sind, ist der Wert im Bin und wir zaehlen eins hoch
     }
   }
   return cnt;
  }

  public static void main(String[] args) {
    // erstellen eines Arrays von double
    double[] simpleData = {1, 2, 2.1, 2, 4, 2.3, 4.1, 4.2, 3, 4, 4.1, 7, 7.1};

    // erstellen eines Histogram Objektes mit 7 Bins
    Histogram hist = new Histogram(simpleData,7);

    // wir geben die Anzahl Elemente pro Bin auf einer gemeinsamen Zeile aus
    for (int i = 0; i<hist.getNumberOfBins(); i++) {
      System.out.print(" "+hist.getNumberOfEntriesInBin(i));
    }
    System.out.println(); // schliesst die Zeile ab
  }

}
