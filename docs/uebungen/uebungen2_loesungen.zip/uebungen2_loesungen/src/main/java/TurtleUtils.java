import static ch.unibas.informatik.jturtle.TurtleCommands.*;

class TurtleUtils {

    /**
     * Setzt die Position vom Turtle an die durch den Punkt gegebene Position.
     */
    static void setTurtlePosition(Point point) {
      // wir gehen ohne zu zeichnen zurueck auf die Ursprungsposition
      penUp();
      home();
  
      // wir laufen an den gegebenen Punkt und drehen uns wider so, dass die Turtle nach oben schaut
      forward(point.getY());
      turnRight(90);
      forward(point.getX());
      turnLeft(90);
    }
    
  }