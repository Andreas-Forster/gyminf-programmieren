import org.junit.Test;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;


public class PalindromTests {


    @Test(timeout = 1000)
    public void testCubicRootPositiveInstances() {
        assertTrue(Palindrom.testPalindrom("anna"));
        assertFalse(Palindrom.testPalindrom("frank"));
        assertTrue(Palindrom.testPalindrom("alula"));
        assertTrue(Palindrom.testPalindrom("eve"));
        assertFalse(Palindrom.testPalindrom("eves"));
    }


    @Test(timeout = 1000)
    public void testPalindromWithCapitatlization() {
        String p1 = "trug Tim eine so helle Hose nie mit Gurt?";
        String p2 = "Eine güldne, guteTugend : Lüge nie!";

        assertTrue(Palindrom.testPalindrom(p1));
        assertTrue(Palindrom.testPalindrom(p2));
        assertFalse(Palindrom.testPalindrom(p1 + "s"));
        assertFalse(Palindrom.testPalindrom("s" + p1));
        

    }
        
}
