
import java.io.IOException;

public class Palindrom  {

  /**
   * Gibt true zurück falls der übergeben String ein Palindrom ist.
   */
  public static boolean testPalindrom(String text) {

    // idee wir schauen von vorne und hinten gleichzeitig ob wir jeweils den selben Buchstaben finden.
    // sie können dies nachstellen, in dem Sie bei einem Beispiel mit Ihren zwei Zeigefinger auf die erste und letzte Stelle zeigen.
    // danach gehen Sie mit beiden Zeigefinger Buchstaben nach Buchstaben zur Mitte solange Sie die gleichen Buchstaben sehen.text

    // erste und letzte Stelle im Text
    int forward = 0;
    int backward = text.length()-1;

    // wenn die Position von vorne nicht mehr kleiner ist als hinten, sind wir fertig mit dem Test
    while( forward<backward) {

      // gehe vorne so lange weiter bis ein Buchstaben gefunden wird
      while( !Character.isLetter(text.charAt(forward))) {
        forward += 1;
      }

      // gehe hinten so lange weiter bis ein Buchstabe gefunden wird
      while( !Character.isLetter(text.charAt(backward))) {
        backward -= 1;
      }

      // verwandle die Buchstaben in Grossbuchstaben und teste ob sie ungleich sind
      if ( Character.toUpperCase(text.charAt(forward)) != Character.toUpperCase(text.charAt(backward))) {

        // Buchstaben sind ungleich, wir haben sicher kein Palindrom und können aufhören
        return false;

      } else {
        
        // wenn die Buchstaben identisch sind haben wir vieleicht ein Palindrom
        // und machen mit den nächsten Buchstaben weiter
        forward += 1;
        backward -= 1;
      }
    }

    return true;
  }


  public static void main(String[] args) throws IOException {
    // Hier kommt ihr eigener Testcode hin


    String test = "Eine güldne, gute Tugend: Lüge nie!";
    System.out.println(testPalindrom(test)); // soll true ausgeben
    System.out.println(testPalindrom("adfsljhadkfuhiu")); // soll false ausgeben
  }
}