
import javax.imageio.ImageIO;
import java.io.File;
import static ch.unibas.informatik.jturtle.TurtleCommands.*;
import java.io.IOException;

public class TurtlePatterns  {

  public static void main(String[] args) throws IOException {
    clear();
    home();
    penColor(BLACK);
    int pattern = Integer.parseInt(args[0]);
    String outputFilename = args[1];

    // Ihr turtle code kommt hierhin

    // Unterscheidung welches Pattern gezeichnet werden soll
    if (pattern == 1) {
      // Winkel ist 120 grad da Kreis/3 also 360/3
      // Von aussen nach innen wird die Länge immer kürzer
      // (alternativ kann man auch von innen nach aussen länger werden)
      for (int i = 100; i > 2; i-=3) {
        forward(i);
        turnRight(120);
      }
    } else if (pattern == 2) {
      // Von aussen nach innen wird Länge kürzer
      // Winkel etwas grösser um den Überlapp hinzubekommen
      for (double d = 100; d > 50; d*=0.98) {
        forward(d);
        turnRight(125);
      }
    }
    
    ImageIO.write(drawing(), "png", new File(outputFilename));
  }
}