import static ch.unibas.informatik.jturtle.TurtleCommands.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class HilbertWalk {

  static final int BASE_LENGTH = 180;
  int depth = 0;
  double lengthLineSegment = 0;

  /**
   * Erzeugt ein neues Objekt HilbertWalk, welches die Hilbertkurve
   * mit angegebener Rekursionstiefe zeichnet.
   */
  HilbertWalk(int depth) {
    clear();
    home();
    penColor(BLACK);
    this.depth = depth;
    this.lengthLineSegment = computeLengthOfLineSegment();
  }


  /** 
   * Gibt die Länge eines Liniensegmentes in der Zeichnung zurück. 
   */
  double computeLengthOfLineSegment() {
    
    // In einem ersten Schritt nutzen Sie die fixe Länge von 6
    // Wenn ihr Code funktioniert, sollen Sie diese Methode so anpassen,
    // dass auf jeder Stufe die Zeichung die Länge BASE_LENGTH hat. 

    // Ihr Code
    // wir wollen die Anzahl Teil-Strecken berechnen,
    // welche auf einem Rekursionslevel gebraucht werden
    int cnt = 1;
    for (int i = 0; i < depth; i++) {
      cnt = cnt * 2 + 1; // jedes tiefere Level braucht 2 mal die Anzahl im höheren Level + 1 Verbindungsstrecke
    }
    
    // die länge berechnet sich aus der gesamten Länge geteilt durch die Anzahl der kleinen Strecken
    return BASE_LENGTH/(double)cnt;
  }

  /**
   * Setzt das Turtle auf die Startposition
   */
  void setStartPosition() {
    penUp();
    home();
    backward(BASE_LENGTH / 2 );
    turnRight(90);
    forward(BASE_LENGTH / 2 );
    turnLeft(90);
    penDown();
  }

 
  /**
   * Zeichnet die Hilbertkurve
   */
  void drawHilbert() {
    setStartPosition();
    penDown();

    // Ihr Code
    drawHilbertA(depth);
    // Alternative Implementation mit einer Methode, jedoch einem zusätzlichen Parameter
    // drawHilberRekursive(depth, 1);
  }
  
  // Implementation der Schritte von der Aufgabe
  void drawHilbertA(int rec) {
    // wenn die Bedingung nicht mehr erfüllt ist, bricht die Rekursion ab
    if ( rec >= 0 ) {
      turnRight(-90);
      drawHilbertB(rec-1);
      forward(lengthLineSegment);
      turnRight(90);
      drawHilbertA(rec-1);
      forward(lengthLineSegment);
      drawHilbertA(rec-1);
      turnRight(90);
      forward(lengthLineSegment);
      drawHilbertB(rec-1);
      turnRight(-90);
    }
  }

  // Implementation der Schritte von der Aufgabe
  void drawHilbertB(int rec) {
    // wenn die Bedingung nicht mehr erfüllt ist, bricht die Rekursion ab
    if ( rec >= 0 ) {
      turnRight(90);
      drawHilbertA(rec-1);
      forward(lengthLineSegment);
      turnRight(-90);
      drawHilbertB(rec-1);
      forward(lengthLineSegment);
      drawHilbertB(rec-1);
      turnRight(-90);
      forward(lengthLineSegment);
      drawHilbertA(rec-1);
      turnRight(90);
    }
  }

  // nicht in der Aufgabenstellung drin, ersetzt die zwei Methoden drawHilbertA und drawHilbertB
  void drawHilberRekursive(int rec, double sign) {
    if ( rec >= 0 ) {
      turnRight(-sign*90);
      drawHilberRekursive(rec-1, -sign);
      forward(lengthLineSegment);
      turnRight(sign*90);
      drawHilberRekursive(rec-1, sign);
      forward(lengthLineSegment);
      drawHilberRekursive(rec-1, sign);
      turnRight(sign*90);
      forward(lengthLineSegment);
      drawHilberRekursive(rec-1, -sign);
      turnRight(-sign*90);
    }

  }

  /**
   * Speichert die Kurve als png Bild unter angegebenem Dateinamen. 
   */
  void saveImage(String filename) {
    BufferedImage image = drawing();

    try {
      ImageIO.write(image, "png", new File(filename));
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }
  }

  public static void main(String[] args) {

    for (int i = 0; i < 5; i++) {
      HilbertWalk walk = new HilbertWalk(i);
      walk.drawHilbert();
      walk.saveImage("hilbert-" + i + ".png");
    }
  }

}
