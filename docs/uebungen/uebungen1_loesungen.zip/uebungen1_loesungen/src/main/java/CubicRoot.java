

public class CubicRoot { 


    public static void main(String[] args) {

        // Ihr Code kommt hierhin

        // Einlesen der Zahl und Genauigkeit für den Abbruch der Iteration
        double a = Double.parseDouble(args[0]);
        final double EPSILON = 1e-8;

        // wir müssen uns immer das aktuelle xn merken sowie das neue xnPlus1 berechnen.
        double xn;
        double xnPlus1 = 1;

        do {
            // das xn+1 von der letzten Iteration ist das neue xn
            xn = xnPlus1;

            // berechne das xn+1 mit Hilfe von xn nach der gegebenen Formel
            xnPlus1 = (1.0/3.0) *(2*xn + a/(xn*xn));

            // Wenn sich der Wert mehr als EPSILON verändert hat, berechnen wir das ganze nocheinmal
        } while( Math.abs(xn-xnPlus1) > EPSILON);

        // Das genaueste Ergebnis steht nun in xnPlus1 und kann ausgegeben werden
        System.out.println(xnPlus1);
    }
}