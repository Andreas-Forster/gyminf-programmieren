class CrossSum {



    public static void main(String[] args) {
        
        // Ihr Code kommt hierhin

        // einlesen der Zahl (siehe Hinweise)
        int zahl = Integer.parseInt(args[0]);

        // die Summe der Ziffern ist am Anfang noch 0
        int sum = 0;

        // Wenn die Zahl negativ ist, merken wir uns das hier,
        // drehen aber das Vorzeichen der Zahl dann um
        int sign = 1;
        if ( zahl < 0 ) {
            zahl = -zahl;
            sign = -1;
        }

        // solange die Zahl grösser ist als 0,
        // zähle die letzte Ziffer zur Summe hinzu (letzte Ziffer mit % 10)
        // und entferne die letzte Ziffer (Ganzzahl Division mit 10)
        while(zahl>0) {
            sum += zahl % 10;
            zahl /= 10;
        }

        // Ausgabe des Resultates, wir müssen nun das Vorzeichen noch richtig setzen
        System.out.println(sum*sign);
    }
}
