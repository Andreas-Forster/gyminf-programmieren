class Comments {

    /**
     * Entfernt alle Kommentare von dem �bergebenen Java Programm.
     */
    public static String removeComments(String javaProgram) {
        
        int pos = 0; // Aktuelle Position an der wir das Java Program anschauen

        int len = javaProgram.length(); // Die L�nge des Java Programms

        String res = ""; // Das Ergebnis, k�nnte auch mit StringBuilder gemacht werden.

        // so lange wir noch nicht fertig sind, machen wir weiter
        while (pos < len) {

            // Fall //-Kommentar
            // (pos < len-1) : teten ob wir mindestens 2 Zeichen vom Ende entfernt sind, sonst kann kein // mehr stehen
            // schauen ob das aktuelle und n�chste Zeichen ein '/' ist, dann beginnt der Kommentar
            if ( (pos < len - 1) && javaProgram.charAt(pos) == '/' && javaProgram.charAt(pos + 1) == '/') {
                // der //-Kommentar endet wenn das Programm zu Ende ist oder wir das Zeilenende '\n' erreichen
                while (pos < len && javaProgram.charAt(pos) != '\n') {
                    pos += 1;// solange dies nicht der Fall ist, schauen wir uns das n�chste Zeichen an
                }

            // Fall /* */-Kommentar
            // (pos < len-1) : teten ob wir mindestens 2 Zeichen vom Ende entfernt sind, sonst kann kein /* mehr stehen
            // schauen ob die n�chste Zeichen zwei Zeichen '/' und '*' sind, dann beginnt der Kommentar
            } else if ( (pos < len - 1) && javaProgram.charAt(pos) == '/' && javaProgram.charAt(pos + 1) == '*') {
                // Da wir nur wohlgeformte Java-Programme anschauen, muss der Kommentar beendet werden.
                // Wir suchen die Stelle wo '*' '/' steht.
                while (javaProgram.charAt(pos) != '*' || javaProgram.charAt(pos + 1) != '/') {
                    pos += 1; // so lange nicht '*' '/' steht, gehen wir zum n�chsten Zeichen
                }
                pos += 1; // wir haben das '*' gefunden, m�ssen nun aber noch zum '/' gehen


            // Wenn wir nicht in einem Kommentar sind, dann ist das Zeichen Teil des Programms
            // und wir h�ngen es an
            } else {
                res += javaProgram.charAt(pos);
            }

            // Das aktuelle Zeichen ist verarbeitet und wir gehen ein Zeichen weiter
            pos += 1;
        }

        // Das Programm steht nun in res und wir geben es zur�ck.
        return res;
    }

    public static void main(String[] args) {
        // Schreiben Sie hier Ihren eigenen Testcode

        // ein String mit Kommentarzeichen (f�r den Test muss es nicht g�ltiger Java Code sein)
        // Das Zeichen '\n' entspricht dem Zeilenumbruch.
        String s = "Dies // kann auch mal /* schief */ gehen \nist ein /* schlechtes \nBeispiel f�r eine */ gutes\nBeispiel f�r eine // bl�de\n/*und unn�tze*/Kommentarfunktion";
        
        System.out.println(s);

        System.out.println("#####################");

        System.out.println(removeComments(s));
    }
}
