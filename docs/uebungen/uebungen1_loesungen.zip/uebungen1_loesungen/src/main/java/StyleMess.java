class StyleMess { // Klasse soll genau gleich heissen wie das File in dem sie steht.

    public static final int A_CONSTANT = 7; // SNAKE_CASE für Konstanten

    // Methoden sollten mit Kleinbuchstaben starten.
    public static void aMethode(int anArgument) {
        double aDoubleVariable = 3.0; // camelCase für Variablen

        // lange Zeilen umbrechen für die Lesbarkeit
        // Diese Methode macht eigentlich gar nichts sinnvolles, zeigt aber an,
        // wie man am besten nicht programmieren würde.
        
        // Abstand zwischen ) und { und vor und nach Operatoren wie ==
        if (A_CONSTANT == 3) {
            System.out.println("Die Konstante ist 3");

            // richtig Einrücken machts lesbarer
            // immer die {}-Klammern schreiben
            // Leerschläge
            //     rund um binäre Operatoren
            //     rund um = bei Zuweisungen
            //     nach ; in der for-Schleife
            for(int i = 0; i < 10; ++i) {
                System.out.println("i ist" + i);
            }
        }
    }

    public static void main(String[] args){
        
    }
}