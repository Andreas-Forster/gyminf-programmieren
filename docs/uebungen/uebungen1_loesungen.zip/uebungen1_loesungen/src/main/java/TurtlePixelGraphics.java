
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import static ch.unibas.informatik.jturtle.TurtleCommands.*;
import java.io.IOException;

public class TurtlePixelGraphics  {

  static final int PIXEL_WIDTH = 2;
  static final int NUMBER_OF_PIXELS_PER_LINE = 50;
  static final int NUMBER_OF_LINES = 50;
  

  /**
   * Zeichnet einen Pixel an der aktuellen TurtlePosition. 
   * Das Argument filled bestimmt ob der Pixel mit der aktuellen 
   * Zeichenfarbe ausgefüllt werden soll. 
   */
  static void drawPixel(boolean filled) {

    penDown();
    penSize(1);
    forward(PIXEL_WIDTH);
    turnRight(90);
    forward(PIXEL_WIDTH);
    turnRight(90);
    forward(PIXEL_WIDTH);
    turnRight(90);
    forward(PIXEL_WIDTH);
    turnRight(90);
    penUp();

    if (filled) {
      forward(PIXEL_WIDTH / 2);
      turnRight(90);
      forward(PIXEL_WIDTH / 2);
      fill();
      backward(PIXEL_WIDTH / 2);
      turnLeft(90);
      backward(PIXEL_WIDTH / 2);
    }
    forward(PIXEL_WIDTH);
    penDown();

  }

  /**
   * Bringt das Turtle auf den Anfang einer Zeile
   */
  static void newLine() {

    penUp();
    backward(NUMBER_OF_PIXELS_PER_LINE * PIXEL_WIDTH);
    turnRight(90);
    forward(PIXEL_WIDTH);
    turnLeft(90);
    penDown();
  }

  /**
   * Zeichnet das übergebene (binäre) Bild. Dabei sollen die 
   * Methoden newLine und drawPixel genutzt werden. 
   */
  public static void drawImage(boolean[][] image) {

    for (int i = 0; i<image.length; i++) {
      for (int j = 0; j<image[i].length; j++) {
        drawPixel(image[i][j]);
      }
      newLine();
    }
  
  }

  /**
   * Beschreibt die implizite Kreisgleichung x^2 + y^2 -radius^2 < 0. Gibt true 
   * zurück wenn x und y innerhalb des mit obiger Gleichung beschriebenen Kreises ist
   * und ansonsten false. 
   */
  public static boolean implicitCircle(double radius, double x, double y) {
    // Ihre Implementation kommt hierhin
    // wir können x*x+y*y-r*r < 0 zurück geben oder
    return radius*radius > x*x+y*y;
  }


  /**
   * Diese Methode soll ein (binäres) Bild erstellen, das einen Kreis mit Radius r im 
   * Zentrum des Bildes zeigt.
   * Dabei soll die oben definierte Methode implicitCircle benutzt werden. 
   */
  public static void drawCircleImage(int radius) {

    // Das Array, welches die Bildinformation beinhaltet
    boolean[][] twoDArray = new boolean[NUMBER_OF_LINES][NUMBER_OF_PIXELS_PER_LINE];

    //  Ihre Implementation kommt hierhin

    // Mittelpunkt mit x und y koordinate in der Mitte (höhe/2, länge/2)
    int mx = NUMBER_OF_LINES/2;
    int my = NUMBER_OF_PIXELS_PER_LINE/2;

    // Wir testen für alle Pixel ob diese im Kreis liegen oder nicht
    for (int i = 0; i< NUMBER_OF_LINES; i++) {
      for ( int j = 0; j<NUMBER_OF_PIXELS_PER_LINE; j++) {

        // i-mx, j-my ist jeweils der Abstand vom Kreismittelpunkt
        twoDArray[i][j] = implicitCircle(radius, i-mx, j-my);
      }
    }

    drawImage(twoDArray);
    
  }



  /**
   * Die Main Methode nimmt als Argument den Radius des Kreises sowie einen 
   * Dateinamen (mit Endung .png)
   * In diese Datei wird dann das erzeugte Bild geschrieben.  
   */
  public static void main(String[] args) throws IOException {
    int radius = Integer.parseInt(args[0]);
    String outputFilename = args[1];
    
    drawCircleImage(radius);
   
    
    BufferedImage image = drawing();
    ImageIO.write(image, "png", new File(outputFilename));
  }
}