

public class NumberConversions {


    /**
     * Diese Methode wandelt eine als String übergebene Binärzahl in 
     * eine Dezimalzahl um und gibt diese zuück.
     * Das Argument hat die Form 0b{0|1}, (also z.B. 0b11110) wobei 
     * das 0b anzeigt, dass es sich hier um einen Binärzahl handelt. 
     */
    public static int binToDec(String numberString) {
        // wir starten an der hintersten Stelle, die hat die Wertigkeit 1
        int positionValue = 1;
        int value = 0;

        // gehe von hinten im Text nach vorne ohne die ersten 2 Zeichen "0b" zu beachten
        for(int i = numberString.length() - 1; i > 1; i--) {
            
            // wenn wir eine '1' finden, müssen wir die Wertigkeit der Stelle zum Wert hinzuzählen
            if(numberString.charAt(i)=='1') {
                value += positionValue;
            }

            // die nächste Stelle hat den doppelten Wert
            positionValue *= 2;
        }

        return value;
    }


    /*
     * Diese Methode wandelt eine gegebene (positive) Dezimalzahl in einen 
     * String um, der die Hexadezimale Form der Zahl ausgibt.
     */
    public static String decToHex(int dec) {
        String s = "";

        // so lange die Zahl noch nicht vollständig in das Hexadezimalformat geschrieben wurde
        do {
            
            // berechne den Wert der letzten Ziffer
            int value = dec%16;

            // falls der Wert 0-9 ist, schreiben wir eine Zahl
            if (value<10) {
                s = value + s;
            } else {

                // Werte von 10-15 schreiben wir als Buchstaben
                s = (char)('A'+value-10) + s;
            }

            // reduziere die Zahl um die letzte Stelle
            dec /= 16;
        } while(dec>0);
        return "0x"+s;

    }


    public static void main(String[] args) {
        
        // behandelt den Fall, dass kein Argument übergeben wurde
        if (args.length < 1) {
            System.out.println("Bitte beim Aufruf eine Zahl übergeben");
        }

        // Wir testen ob das erste Argument mit "0b" beginnt -> binToDec
        String numberString = args[0];
        if (numberString.trim().startsWith("0b")) {
            System.out.println(binToDec(numberString));

        // Wir gehen davon aus, dass keine falschen Argumente übergeben werden und führen alternativ decToHex aus
        } else {
            int i = Integer.parseInt(numberString); // wir müssen aus dem String noch eine Zahl vom Typ int machen
            System.out.println(decToHex(i));
        }

    }
}