
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import static ch.unibas.informatik.jturtle.TurtleCommands.*;

public class Snowflake {
  
  // Die maximale Rekursionstiefe 
  int depth = 0;

  // Länge der Kochkurve
  static final int LENGTH_OF_CURVE = 120;

  /**
   * Kreiert eine Schneeflocke mit angegebener maximaler Rekursionstiefe
  */
  Snowflake(int depth) {
    clear();
    home();
    penColor(BLACK);
    this.depth = depth;
  }

  /**
   * Setzt das Turtle auf die Startposition
   */
  void setStartPosition() {
    penUp();
    home();
    forward(LENGTH_OF_CURVE * 0.3 );
    turnRight(90);
    backward(LENGTH_OF_CURVE * 0.5);
    penDown();
  }

  /** 
   * Zeichnet die Kochkurve auf dem aktuellen Rekursionslevel. 
   * Das Argument length gibt an wie lange ein Liniensegment sein soll
   */
  void drawKochCurve(int currentDepth, double length) {
    // Ihr Code

    // wenn die Rekursion abbricht, gehen wir einfach forwärts
    if (currentDepth == depth) {
      forward(length);
    } else {
      // ein Rekursionslevel ist "K-K++K-K" mit
      // K: rekursiver Aufruf um ein höheres Level mit 1/3 der Länge
      // -: nach links drehen um 60 Grad
      // +: nach rechts drehen um 60 Grad 
      drawKochCurve(currentDepth+1, length/3.0);
      turnLeft(60);
      drawKochCurve(currentDepth+1, length/3.0);
      turnRight(120);
      drawKochCurve(currentDepth+1, length/3.0);
      turnLeft(60);
      drawKochCurve(currentDepth+1, length/3.0);
    }
  }


  /**
   * Zeichnet eine Scheeflocke, durch mehrmaliges zeichnen der Kochkurve
   */
  void drawSnowflake() {
    setStartPosition();
   
    // Ihr Code
    
    // K++K++K ergibt die Schneeflocke
    drawKochCurve(0, LENGTH_OF_CURVE);
    turnRight(120);
    drawKochCurve(0, LENGTH_OF_CURVE);
    turnRight(120);
    drawKochCurve(0, LENGTH_OF_CURVE);
  }


  /**
   * Speichert das gezeichnete Bild.
   */
  void saveImage(String filename) {
    BufferedImage image = drawing();

    try {
      ImageIO.write(image, "png", new File(filename));
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }
  }

  /**
   * Testprogramm um Zeichnung mit verschiedenen Rekursionstiefen zu generieren. 
   */
  public static void main(String[] args) {

    // Führt das Programm für Rekursionstiefen 0 1 und 2 aus. 
    for (int i = 1; i <= 4; i++) {
      Snowflake flake = new Snowflake(i);
      flake.drawSnowflake();
      flake.saveImage("snowflake " + i + ".png");
    }
  }

}
