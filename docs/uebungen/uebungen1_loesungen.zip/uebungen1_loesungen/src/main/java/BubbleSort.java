
class BubbleSort {

    /**
     * Vertauscht zwei Werte in einem Array an den gegebenen Positionen.
     **/
    public static void swap(int i, int j, int[] a) {

        // wichtig, wir m�ssen einen Wert zwischenspeichern um 2 Werte zu tauschen
        int h = a[i];
        a[i] = a[j];
        a[j] = h;
    }

    /**
     * Sortiert das Eingabearray und �ndert das Array a so, dass die Elemente danach
     * aufsteigend sortiert sind.
     **/
    public static void sort(int[] a) {
        // wenn das Array nicht mindestens 2 Werte hat, sind wir schon fertig
        if ( a.length<2) {
            return;
        }
        
        // Bubblesort l�sst den gr�ssten Wert "aufsteigen" bis an die letzte Position
        // wir m�ssen dies h�chstens so oft widerholen wie das Array Elemente hat
        for(int i = 0; i<a.length; i++) {

            // Optional f�r Effizienz: wir merken uns, ob wir mindestens ein paar von Elementen
            // vertauschen mussten (wenn nicht, w�ren wir fertig)
            boolean swapped = false;

            // wir beginnen vorne und schauen der Reihe nach alle Element-Paare an ob wir tauschen m�ssen
            // Effizienz: wir m�ssen die letzten i-Elemente nicht anschauen, da die schon richtig sind
            for(int j = 0; j<a.length-i-1; j++) {
                
                // tausche die Elemente wenn das erste das gr�ssere Element ist
                if ( a[j] > a[j+1] ) {
                    swap(j, j+1, a);
                    swapped = true;
                }
            }

            // wenn kein Tausch vorgenommen wurde, sind wir fertig
            if (!swapped) {
                return;
            }
        }
    }

    /**
     * Schreibt das Array auf die Ausgabekonsole, z.B. "[0, 1, 4, 8, 9]"
     **/
    public static void displayArray(int[] a) {

        // wir �ffnen das Array
        System.out.print("[");

        // schreibe alle Elemente bis auf das letzte auf die Konsole
        // solange wir nicht das letzte Element geschrieben haben, folgt ein Komma ", "
        for (int i = 0; i < a.length - 1; i++) {
            System.out.print(a[i] + ", ");
        }

        // wir schreiben das letzte Element raus, da folgt kein Komma
        if (a.length > 0) {
            System.out.print(a[a.length - 1]);
        }
        // wir schliessen das Array
        System.out.println("]");
    }

    /**
     * Die Hauptfunktion liest ein Array von den Kommandozeilenargumenten und ruft
     * die Sortierfunktion und die Ausgabefunktion auf
     **/
    public static void main(String[] args) {

        // anlegen eines Arrays welches die gleiche L�nge hat
        // wie die Anzahl der dem Programm �bergebenen Argumente
        int[] a = new int[args.length];

        // Jedes Argument wird in ein int umgewandelt und an
        // die entsprechende Stelle im Array gespeichert
        for (int i = 0; i < args.length; i++) {
            a[i] = Integer.parseInt(args[i]);
        }

        System.out.println("Array vor dem Sortieren");
        displayArray(a);

        // Aufruf der Sortierfunktion welche das Array-ver�ndert
        sort(a);

        System.out.println("Array nach dem Sortieren");
        displayArray(a);
    }
}
