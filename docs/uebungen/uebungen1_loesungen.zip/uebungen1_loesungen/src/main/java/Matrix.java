class Matrix {

  /**
   * Gibt die Transponierte der Übergebenen Matrix zurück. 
   * Die Übergebene Matrix darf nicht verändert werden. 
   */
  static double[][] transpose(double[][] matrix) {

    // Ihr Code kommt hierhin

    // Wenn das äussere Array keine Elemente hat,
    // dann gibt es keine inneren Arrays.
    // Wir erstellen eine leeres 2d-Array. 
    if (matrix.length==0) {
      return new double[0][0];
    }

    // Wir erstellen ein 2d Array mit vertauschten Längen.
    double[][] t = new double[matrix[0].length][matrix.length];

    // Wir greifen auf das Element i,j zu dies kommt an die Stelle j,i
    for (int i = 0; i<matrix.length; i++) {
      for (int j = 0; j<matrix[i].length; j++) {
        t[j][i] = matrix[i][j];
      }
    }
  
    return t;
  }

  /*
  * Hilfsfunktion um eine Matrix auszugeben. 
  */
  static void displayMatrix(double[][] matrix) {
    for (int i = 0; i < matrix.length; i++) {
      System.out.print("[ ");
      for (int j = 0; j < matrix[0].length; j++) { 
        System.out.print(matrix[i][j] + " ");
      }
      System.out.println("]");
    }
  }


  public static void main(String[] args) { 

      // Schreiben Sie hier ihren eigenen Code um das Programm zu testen

      // Wir erstellen eine Matrix 4x2
      double[][] m = {
        {1, 2},
        {3, 4},
        {5, 6},
        {7, 8},
        {9, 0}
      };

      displayMatrix(m);

      System.out.println("############");

      // transponieren der Matrix ändert m nicht
      double[][] mt = transpose(m);
      displayMatrix(mt);
  }  


}