/**
 * Testklasse für das GameOfLife.
 */
public class GameOfLifeCommandLine {

  GameOfLife gol;

  /**
   * Kreiert eine Visualisierung mit dem das übergebene Game Of Life
   * angezeigt und simuliert werden kann.
   */
  public GameOfLifeCommandLine(GameOfLife gol) {
    this.gol = gol;
  }

  /**
   * Diese Methode führt numSteps update steps für das 
   * übergebene GameOfLife-objekt aus und gibt jeden 
   * zwischenschritt aus. 
   */
  public void run(int numSteps) {
    // Ihre Implementation
  }

  public static void main(String[] args) {    
    GameOfLife gol = new GameOfLife(
      GameOfLife.createBlinker()
    );
    GameOfLifeCommandLine golCommandLine = new GameOfLifeCommandLine(gol);
    golCommandLine.run(100);
  }
}
