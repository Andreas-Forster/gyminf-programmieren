public class BMI { 

    public static void main(String[] args) {

        // Schreiben Sie hier ihren Code

    }
}