import static ch.unibas.informatik.jturtle.TurtleCommands.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Squares {
  
  public static void main(String[] args) throws IOException {

    // Test dass ein Filenamen als Argument übergeben wurde
    if (args.length < 1) {
      System.out.println("Usage: Squares imageFilename");
      System.out.println("Example (Win): java -cp \".;jturtle-0.6.jar\" Squares out.png");
      System.out.println("Example (OS X, Linux): java -cp .;jturtle-0.6.jar\" Squares out.png");
      System.exit(-1);
    }

    String outputImageFileName = args[0];
   
    // Schreiben Sie zwischen dem und dem nächsten Kommentar Ihre Turtle Befehle hin



    

    // Schreiben des Bildes als File
    BufferedImage image = drawing();
    ImageIO.write(image, "png", new File(outputImageFileName));
  }
}

