
import edu.illinois.cs.cs125.gradlegrader.annotations.Graded;
import edu.illinois.cs.cs125.gradlegrader.annotations.Tag;
import org.junit.Test;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import static org.junit.Assert.assertTrue;

public class BMITests {


    @Test(timeout = 300)
    @Graded(points = 1)
    @Tag(name = "difficulty", value = "simple")
    @Tag(name = "function", value = "BMImain")
    public void testAufgabe2BerechnungRichtig() {
        String output = runBMIAndCaptureOutput("188", "88");
        String[] lines = output.split("\\r?\\n");
        String res = lines[0].split(":")[1].trim();
        assertTrue(Math.abs(Double.parseDouble(res) - 24.9) < 0.1);
    }

    @Test(timeout = 300)
    @Graded(points = 2)
    @Tag(name = "difficulty", value = "simple")
    @Tag(name = "function", value = "BMImain")
    public void testAufgabe2AusgabeRichtig() {
        
        String output = "";
        String[] lines = null;

        String weightForLowBMI = Integer.valueOf((int) (1.88 * 1.88 * 17)).toString();
        output = runBMIAndCaptureOutput("188", weightForLowBMI);
        lines = output.split("\\r?\\n");
        assertTrue(lines[1].contains("unter"));

        String weightForAvgBMI = Integer.valueOf((int) (1.88 * 1.88 * 24)).toString();
        output = runBMIAndCaptureOutput("188", weightForAvgBMI);
        lines = output.split("\\r?\\n");
        assertTrue(lines[1].contains("zwischen"));

        String weightForHighBMI = Integer.valueOf((int) (1.88 * 1.88 * 26)).toString();
        output = runBMIAndCaptureOutput("188", weightForHighBMI);
        lines = output.split("\\r?\\n");        
        assertTrue(lines[1].toLowerCase().contains("ber")); 
    }


    private String runBMIAndCaptureOutput(
        String argument1, 
        String argument2
    ) {
        
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        
        System.setOut(new PrintStream(outContent));       
        
        String[] args = {argument1, argument2};
        
        BMI.main(args);
        String output = outContent.toString();

        System.setOut(originalOut);
        return output;
        
    }           
}
