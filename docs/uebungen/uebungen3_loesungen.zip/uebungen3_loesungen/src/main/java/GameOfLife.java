import java.util.Random;

/**
 * Dieses Objekt simuliert ein GameOfLife mit einer fixen Konfiguration
 */
public class GameOfLife {

  // Ihre Felder
  boolean[][] field; // speichert den Zustand des GameOfLife "Spiel"Feldes
  int size; // speichert die Grösse, wir beschränken uns auf quadratische Felder
  // Für Fleissige: schaffen Sie es das ganze für nicht quadratische Felder umzubauen?

  /**
   * Kreiert eine neue Instanz vom Game Of Life. Dabei wird die 
   * Startkonfiguration im array cells übergeben.
   */
  public GameOfLife(boolean[][] cells) {
    // Ihre Implementation
    this.field = cells; // Zuweisen des übergebenen Zustandes an die Objekt-Variable
    this.size = cells.length; // da das Feld quadratisch ist, schauen wir einfach die Länge des Arrays an.
  }

  /**
   * Gibt die grösse des Game of Life zurück unter der Annahme, dass das Feld quadratisch ist.
   */
  public int getSize() {
    return field.length;
  }

  /**
   * Gibt true zurück, falls die Zelle an der Stelle i,j
   * aktiv ist. 
   */
  public boolean isActive(int i, int j) {
    // Ihre Implementation
    // (n+len)%len um den Zugriff zyklisch hinzubekommen bei -1 auf len-1 und bei len auf 0
    int x = (i+size)%size;
    int y = (j+size)%size; // da das Feld quadratisch ist, können wir hier zweimal das selbe berechnen.
    return field[x][y];
  }

  /**
   * Gibt die Anzahl aktiver Nachbarn zurück.   
   */
  public int getNumberOfActiveNeighbors(int i, int j) {
    /* wir laufen von -1 bis +1 rund um i und j
       -1/1   0/1   1/1
       -1/0   i/j   1/0
       -1/-1  0/-1  1/-1  */
    int sum = 0;
    for (int di = -1; di<2; di++) { // von i-1 bis i+1
      for (int dj = -1; dj<2; dj++) { // von j-1 bis j+1
        if ( isActive(i+di,j+dj) ) {
          sum += 1;
        }
      }
    }
    // wir haben i,j mitgezählt zu den Nachbarn gezählt, wenn es aktiv ist
    if (field[i][j]) {
      sum -= 1;
    }
    return sum;
  }

  /**
   * Führt einen Updateschritt gemäss  
   * den Regeln vom Game Of Life aus (siehe Übungsblatt).
   */
  public void update() {
    // neues Feld für die nächste "Generation"
    // So verändern wir Zellen im aktuellen Zustand nicht schon während der Berechnung des neuen Zustandes.
    boolean[][] next = new boolean[field.length][field[0].length];

    // wir müssen jede Zelle im Feld anschauen
    for (int i = 0; i<field.length; i++) {
      for ( int j = 0; j<field[0].length; j++) {
        // zählen der aktiven Nachbarn 
        int aliveNeighbours = getNumberOfActiveNeighbors(i, j);

        // Regeln ... 
        if ( field[i][j] ) { // lebende Zelle
          next[i][j] = (aliveNeighbours == 2) || (aliveNeighbours == 3); // bleiben am leben bei 2 und 3 lebenden Nachbarn
        } else { // tote Zellen...
          next[i][j] = aliveNeighbours == 3; //erwachen bei 3 lebenden Nachbarn zum leben
        }
      }
    }

    // das Update ist berechnet, jetzt können wir das Feld updaten
    field = next;
  }


  /**
   * Gibt die Konfiguration als formtierten String zurück
   * (Details siehe Übungsblatt)
   */
  public String toString() {

    // String schrittweise aufbauen geht am besten mit StringBuilder
    StringBuilder sb = new StringBuilder();

    // Wir laufen über alle Zellen, äussere Schleife über die Zeilen
    for (int i = 0; i<field.length; i++) {
      for ( int j = 0; j<field[0].length; j++) {
        if (field[i][j]) { // Unterschiedliche Zeichen für lebende und tote Zellen
          sb.append('@');
        } else {
          sb.append('.');
        }
      }
      sb.append('\n'); // Zeilenumbruch '\n' am Ende jeder Zeile
    }

    // wir geben den gebauten String zurück
    return sb.toString();
  }

  // In der Aufgabe nicht verlangte Methode,
  // schaut ob mindestens eine Zelle am Leben ist, sonst würde sich nichts mehr ändern.
  public boolean hasAliveCell() {
    for (int i = 0; i<field.length; i++) {
      for ( int j = 0; j<field[0].length; j++) {
        if ( field[i][j] ) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Kreiert ein neues Game Of Life Objekt mit der Startkonfiguration
   * block.
   */
  public static boolean[][] createBlock() {
    // Ihre Implementation
    return new boolean[][]{
        {false, false, false, false},
        {false,  true,  true, false},
        {false,  true,  true, false},
        {false, false, false, false}
      };
  }

 /**
   * Kreiert ein neues Game Of Life Objekt mit der Startkonfiguration
   * blinker.
   */
  public static boolean[][] createBlinker() {
    // Ihre Implementation
    return new boolean[][]{
        {false, false, false, false, false},
        {false, false,  true, false, false},
        {false, false,  true, false, false},
        {false, false,  true, false, false},
        {false, false, false, false, false}
      };
  }

   /**
   * Kreiert ein neues Game Of Life Objekt mit der Startkonfiguration
   * Glider.
   */
  public static boolean[][] createGlider() {
    // Ihre Implementation
    return new boolean[][]{
        {false, false, false, false, false, false},
        {false,  true, false,  true, false, false},
        {false, false,  true,  true, false, false},
        {false, false,  true, false, false, false},
        {false, false, false, false, false, false},
        {false, false, false, false, false, false}
    };
  }

  /**
   * Kreiert ein neues Game Of Life Objekt der Grösse size.
   * Dabei ist jede Zelle mit der angegebenen Wahrscheinlichkeit aktiv.
   */
  public static boolean[][] createRandom(int size, double probability) {
    assert(probability >= 0 && probability <= 1);

    // Ihre Implementation
    Random rng = new Random(); // erstellen des Zufallszahlengenerators
    boolean[][] field = new boolean[size][size]; // neues Feld erstellen

    for (int i = 0; i<field.length; i++) {
      for ( int j = 0; j<field[0].length; j++) {
        // wenn Zufallszahl zwischen 0 und probability ist, dann setzen wir die Zelle auf true, sonst false
        field[i][j] = rng.nextDouble() < probability;
      }
    }
    return field;
  }

  public static void main(String[] args) {
    // hier kommt Ihr Testcode hin
    // boolean[][] randomField = createBlock();
    // boolean[][] randomField = createBlinker();
    // boolean[][] randomField = createGlider();
    boolean[][] randomField = createRandom(16,0.3); // wir erstellen initiale Werte

    GameOfLife gol = new GameOfLife(randomField); // wir erstellen ein GameOfLife
    System.out.println(gol); // Ausgabe des initialen Zustands

    // solange mindestens noch eine Zelle am Leben ist, könnte aber auch einfach 10 Iterationen sein
    while(gol.hasAliveCell()) {
      gol.update();
      System.out.println(gol); // hier ruft Java automatisch die toString-Methode der Klasse GameOfLife auf
    }
  }

}
