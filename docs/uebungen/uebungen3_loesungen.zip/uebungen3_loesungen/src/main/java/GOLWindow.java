import javax.swing.*;
import java.awt.*;


/** 
 * Grafische Visualisierung vom Game Of Life mittels AWT.
 * 
 * Wir leiten von JFrame ab, welches eine Klasse ist um ein Fenster zu öffnen.
 */
public class GOLWindow extends JFrame {

  GameOfLife gol;

  /**
   * Kreiert eine Visualisierung mit dem das übergebene GameOfLife
   * angezeigt und simuliert werden kann.
   */
  public GOLWindow(GameOfLife gol) {
    this.gol = gol;
    this.add(new GOLDrawingArea(gol));
    this.pack();
    setVisible(true);
  }


  /**
   * Diese Methode führt für die Simulation numSteps update Schritte für das
   * GameOfLife-Objekt aus und visualisiert jeden Zwischenschritt.
   * Für die Visualisierung müssen Sie nur die Methode repaint() nach dem Update aufrufen.
   * Wenn Ihnen die Visualisierung zu schnell ist, dann nutzen Sie die statische Methode
   * Thread.sleep(N) um jeweils eine bestimmte Zeit in Millisekunden zwischen zwei Schritten
   * zu warten wenn.
   */
  public void run(int numSteps) throws Exception {
    // Ihre Implementation
    for (int i = 0; i < numSteps; i++) {
      gol.update();
      repaint(); // anstelle der Ausgabe auf die Kommandozeile zeichnen wir das Feld neu
      Thread.sleep(10);
    }
  }

  /**
   * Erstellen Sie hier ein GameOfLife in dem Sie auch eine der statischen
   * Methoden verwenden. Übergeben Sie dann das GameOfLive dem Konsruktor
   * des GOLWindow. Rufen Sie dann die run-Methode von dem GOLWindow auf
   * um die Visualisierung zu sehen.
   */
  public static void main(String[] args) throws Exception {
    // Ihre Implementation
    GameOfLife gol = new GameOfLife(GameOfLife.createRandom(147, 0.4)); // hier könnten wir auch das ChangedBorderCondition verwenden.
    GOLWindow golF = new GOLWindow(gol); // erstellen der Visualisierung
    golF.run(100); // wir berechnen 100 update schritte
  }

}




/**
 * Dieses JPanel repräsentiert die Zeichenfläche, mit der mittels den AWT Befehlen
 * gezeichnet werden kann. Sie können Sich das als ein Art Blatt Papier vorstellen
 * worauf Sie zeichnen können. Diese wird dann im JFrame angezeigt.
 */
class GOLDrawingArea extends JPanel {

  GameOfLife gol;
  
  static final Color GREEN = new Color(0,255,0);
  static final Color BLACK = new Color(0,0,0);

  int pixelSize;

  /**
   * Kreiert eine Visualisierung mit dem das übergebene GameOfLife
   * angezeigt und simuliert werden kann.
   * Berechnen Sie die Grösse der Pixels anhand der Grösse (600)
   * des Zeichen bereichs und der Grösse des GameOfLifes.
   */
  GOLDrawingArea(GameOfLife gol) {
    this.gol = gol;
    setSize(600, 600);
    // Ihre Implementation
    pixelSize = 600/gol.getSize();
  }


  /**
   * Zeichnet den aktuellen Zustand vom Game of Life. 
   * Zum Zeichnen wird das übergebene Grafik objekt g genutzt.
   * Die Idee ist, dass Sie jeden Pixel als Quadrat zeichnen,
   * jeweils mit einer anderen Farbe für lebende und nicht lebende Zellen.
   * Verwenden Sie die Methoden:
   *   g.drawRect(x, y, width, height);
   *   g.fillRect(x, y, width, height);
   *   g.setColor(...); // übergeben Sie eine der Konstanten GREEN oder BLACK
   */
  public void paint(Graphics g) {
    // Ihre Implementation
    for (int i = 0; i<gol.getSize(); i++) {
      for (int j = 0; j<gol.getSize(); j++) {
        int x = i*pixelSize;
        int y = j*pixelSize;
        if (gol.isActive(i, j)) {
          g.setColor(GREEN);
          g.fillRect(x, y, pixelSize,pixelSize);
        } else {
          g.setColor(BLACK);
          g.drawRect(x, y, pixelSize,pixelSize);
        }
      }
    }
  }

  // Gibt die gewünschte Grösse des Fensters zurück.
  public Dimension getPreferredSize() {
    return new Dimension(600, 600);
  }
}