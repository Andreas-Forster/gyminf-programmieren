public class ChangedBorderCondition extends GameOfLife {
    ChangedBorderCondition(boolean[][] field) {
        super(field); // Wir rufen den Konstruktor für die Oberklasse (GameOfLife) auf.
        // Der speichert dann das Feld und die Grösse
        // Mehr müssen wir in diesem Fall nicht tun.
    }

    // überschreiben der isActive-Methode mit neuer Randbedingung (nicht mehr Zyklischer-Zugriff, sondern einfach true)
    @Override
    public boolean isActive(int i, int j) {
        // wenn immer wir ausserhalb des Feldes zugreifen, geben wir true zurück
        if (i<0 || j<0 || i >= field.length || j >= field.length) {
            return true;
        } else {
            return field[i][j];
        }
    }
}
