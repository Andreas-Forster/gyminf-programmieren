class Histogram {

  // Felder um die Daten sowie die Anzahl Bins zu speichern
  double[] data = null;
  int numberOfBins;

  /**
   * Erzeugt ein Histogram Objekt f�r die �bergebenen Gleitkommazahlen (daten),
   * mit den angegebenen anzahl Klassen (bins). Die Daten sollen in einem Feld
   * data und die anzahl Klassen in einem Feld numberOfBins gespeichert.
   */
  Histogram(double[] data, int numberOfBins) {
    this.data = data;
    this.numberOfBins = numberOfBins;
  }

  /**
   * Gibt die Anzahl Klassen (bins) zur�ck
   */
  int getNumberOfBins() {
    return this.numberOfBins;
  }

  /*
   * gibt die im Histogram gespeicherten Daten zur�ck
   */
  double[] getData() {
    return this.data;
  }

  /**
   * Gibt die Gr�sse einer Klasse (also das Interval zur�ck). Die Intervallgr�sse
   * berechnet sich als (max - min) / #bins, wobei max der Maximalwert in den
   * Daten ist, min der MinimalWert und #bins die Anzahl klassen.
   */
  public double getBinSize() {
    // Ihre Implementation
    return 0.0;
  }

  /**
   * Gibt den kleinsten Wert in den Daten zur�ck
   */
  public double getMinValue() {
    // Ihre Implementation
    return 0.0;
  }

  /**
   * Gibt den gr�ssten Wert in den Daten zur�ck
   */
  public double getMaxValue() {
    // Ihre Implementation
    return 0.0;
  }


  /**
   * Gibt f�r eine gegebene Klasse (bestimmt durch binNumber) die Anzahl
   * Datenelemente zur�ck die in diese Klasse fallen. Wir beginnen bei 0 zu
   * z�hlen. Das erste Bin hat also den index 0. Der gr�sste Wertf�llt in den
   * letzten Bin
   * 
   * Beispiel: Angenommen wir h�tten die Daten [4.1, 1.5, 5.0, 1.0, 3.0, 3.5, 4.0,
   * 3.1] und 4 bins. Dann w�re getNumberOfEntriesInBin(0) = 2 (n�mlich 1.0 und
   * 1.5) getNumberOfEntriesInBin(1) = 0 getNumberOfEntriesInBin(2) = 3 (n�mlich
   * 3.0, 3.1, 3.5) getNumberOfEntriesInBin(3) = 3 (n�mlich 4.0, 4.1, 5.0)
   * 
   * Beachten Sie, dass das letzte Bin speziell behandelt werden muss, da es
   * zus�tzlich auch das maximale Element beinhaltet
   */
  public int getNumberOfEntriesInBin(int binNumber) {
   // Ihre Implementation 
   return 0;
  }

  public static void main(String[] args) {
    // hier k�nnen Sie ihren eigenen Testcode schreiben.
  }

}
