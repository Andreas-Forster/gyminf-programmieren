import static ch.unibas.informatik.jturtle.TurtleCommands.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

class PlotAxes {

  // Definieren Sie hier alle Felder die Sie ben�tigen.

  /**
   * Kreiert ein Objekt der Klasse PlotAxes, welches durch den Koordinatenursprung
   * (also den Punkt unten Links) sowie die L�ngen der x und y-Achse definiert
   * ist.
   */
  PlotAxes(Point origin, double lengthXAxis, double lengthYAxis) {
    // Ihre Implementation
  }

  /**
   * Diese Methode nutzt das als Argument �bergebene Turtle um die
   * Koordinatenachsen an der vorgegebenen Position zu zeichnen. Nutzen Sie die
   * statische Methode TurtleUtils.setTurtlePosition um das Turtle an die richtige
   * Position zu setzen.
   */
  void drawWithTurtle() {
    // Ihre Implementation
  }

  /**
   * Einfaches Testprogramm um Ihre Zeichnung zu testen
   */
  public static void main(String[] args) {
    home();
    clear();
    PlotAxes pa = new PlotAxes(new Point(-30, -50), 60, 100);
    pa.drawWithTurtle();

    BufferedImage img = drawing();

    try {
      ImageIO.write(img, "png", new java.io.File("axes.png"));
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
  }

}