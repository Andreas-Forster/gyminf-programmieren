
class Point {

    // Definieren Sie hier alle Felder die Sie ben�tigen.

    /**
     * Erzeugt ein neues Objekt mit den Koordinaten x und y
     */
    Point(double x, double y) {
        // Ihre Implementation
    }

    /**
     * Gibt die x-Koordinate zur�ck
     */
    double getX() {

        // Ihre Implementation 
        // (ersetzen Sie das folgende return statement)
        return 0.0;
    }

    /**
     * Gibt die y-Koordinate zur�ck
     */
    double getY() {

        // Ihre Implementation 
        // (ersetzen Sie das folgende return statement)
        return 0.0;
    }

    public static void main(String[] args) {
        // hier k�nnen Sie ihren eigenen Testcode schreiben.
    }

}
