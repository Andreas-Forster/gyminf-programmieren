import static ch.unibas.informatik.jturtle.TurtleCommands.*;


class TurtleUtils {

    /**
     * Setzt die Position vom Turtle an die durch den Punkt gegebene Position.
     */
    static void setTurtlePosition(Point point) {
      penUp();
      home();
  
      forward(point.getY());
      turnRight(90);
      forward(point.getX());
      turnLeft(90);
    }
    
  }