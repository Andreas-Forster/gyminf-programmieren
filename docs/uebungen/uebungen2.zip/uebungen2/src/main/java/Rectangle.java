import static ch.unibas.informatik.jturtle.TurtleCommands.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

class Rectangle {

  // Definieren Sie hier alle Felder die Sie ben�tigen.

  /**
   * Kreiert ein neues Rectangle Objekt, welches ein Rechteck durch den unteren
   * Linken Punkt, sowie dessen Breite und H�he definiert.
   */
  Rectangle(Point lowerLeftCorner, double width, double height) {
    // Ihre Implementation
  }

  /**
   * Diese Methode nutzt das als Argument �bergebene Turtle um das Rechteck an der
   * vorgegebenen Position zu zeichnen. Nutzen Sie die statische Methode
   * TurtleUtils.setTurtlePosition um das Turtle an die richtige Position zu
   * setzen.
   */
  void drawWithTurtle() {
    // Ihre Implementation
  }

    /**
     * Einfaches Testprogramm um Ihre Zeichnung zu testen
     */
    public static void main(String[] args) {
      clear();
      home();

      Rectangle rect = new Rectangle(new Point(-30, -50), 60, 100);
      rect.drawWithTurtle();

      BufferedImage img = drawing();

      try {
        ImageIO.write(img, "png", new java.io.File("rectangle.png"));
      } catch (IOException e) {
        System.err.println(e.getMessage());
      }
  }
}
