
import edu.illinois.cs.cs125.gradlegrader.annotations.Graded;
import edu.illinois.cs.cs125.gradlegrader.annotations.Tag;
import org.junit.Test;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;

import static org.junit.Assert.*;

public class SquaresTest {


    @Test(timeout = 10000)
    @Graded(points = 4)
    @Tag(name = "difficulty", value = "simple")
    @Tag(name = "function", value = "Welcome.main")
    public void testOutputImageTheSame() {
        try {

            File outputImageFile = File.createTempFile("square", ".png");
            String[] args = {outputImageFile.getAbsolutePath()};


            // produces a file called
            Squares.main(args);

            BufferedImage outputImage = ImageIO.read(outputImageFile);

            File groundTruthImageFile = new File("src/test/resources/squares.png");

            BufferedImage groundTruthImage = ImageIO.read(groundTruthImageFile);

            assertEquals("heigth matches", groundTruthImage.getHeight(), outputImage.getHeight());
            assertEquals("width matches", groundTruthImage.getWidth(), outputImage.getWidth());

            for (int i = 0; i < groundTruthImage.getWidth(); i++) {
                for (int j = 0; j < groundTruthImage.getHeight(); j++) {
                    assertEquals("Pixel (" +i + ", "+j  + ") matches", groundTruthImage.getRGB(i, j), outputImage.getRGB(i, j));
                }
            }

        } catch (IOException e) {
            fail("IOException occured " +e.getMessage());
            e.printStackTrace();
        }


    }


}
