
import org.junit.Test;
import static ch.unibas.informatik.jturtle.TurtleCommands.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static org.junit.Assert.*;

public class TurtlePixelGraphicsTests {

    @Test(timeout = 10000)
    public void testCircleEquation() {
        assertEquals(true, TurtlePixelGraphics.implicitCircle(1, 0, 0));
        assertEquals(true, TurtlePixelGraphics.implicitCircle(3, 1, 1));
        assertEquals(false, TurtlePixelGraphics.implicitCircle(1, 1, 1));
    }

    @Test(timeout = 10000)
    public void testDrawImage() {

        try {

            File groundTruthImageFile = new File("src/test/resources/squareImage.png");
            BufferedImage groundTruthImage = ImageIO.read(groundTruthImageFile);

            boolean[][] img = new boolean[TurtlePixelGraphics.NUMBER_OF_LINES][TurtlePixelGraphics.NUMBER_OF_PIXELS_PER_LINE];
            for (int i = 0; i < img.length; i++) {
                for (int j = 0; j < img[i].length; j++) {
                    if (i >= img.length / 4 && j >= img.length / 4 && i <= (int) (img.length * 3 / 4.0)
                            && j <= (int) (img.length * 3 / 4.0)) {
                        img[i][j] = true;
                    } else {
                        img[i][j] = false;
                    }
                }
            }

            clear();
            home();
            TurtlePixelGraphics.drawImage(img);
            BufferedImage drawnImage = drawing();
            
            assertImageEquals(groundTruthImage, drawnImage);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    @Test(timeout = 10000)
    public void testCircleImage() {

        try {

            File groundTruthImageFile = new File("src/test/resources/circleImage.png");
            BufferedImage groundTruthImage = ImageIO.read(groundTruthImageFile);

            clear();
            home();

            TurtlePixelGraphics.drawCircleImage(20);
            BufferedImage drawnImage = drawing();

            assertImageEquals(groundTruthImage, drawnImage);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    void assertImageEquals(BufferedImage groundTruthImage, BufferedImage drawnImage) {

        assertEquals("heigth matches", groundTruthImage.getHeight(), drawnImage.getHeight());
        assertEquals("width matches", groundTruthImage.getWidth(), drawnImage.getWidth());

        for (int i = 0; i < groundTruthImage.getWidth(); i++) {
            for (int j = 0; j < groundTruthImage.getHeight(); j++) {
                assertEquals("Pixel (" + i + ", " + j + ") matches", groundTruthImage.getRGB(i, j),
                        drawnImage.getRGB(i, j));
            }
        }
    }

}
