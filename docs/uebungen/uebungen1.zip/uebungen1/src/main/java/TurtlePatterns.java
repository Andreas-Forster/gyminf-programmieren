
import javax.imageio.ImageIO;
import java.io.File;
import static ch.unibas.informatik.jturtle.TurtleCommands.*;
import java.io.IOException;

public class TurtlePatterns  {

  public static void main(String[] args) throws IOException {
    clear();
    home();
    penColor(BLACK);
    int pattern = Integer.parseInt(args[0]);
    String outputFilename = args[1];

    // Ihr turtle code kommt hierhin
    

    ImageIO.write(drawing(), "png", new File(outputFilename));
  }
}