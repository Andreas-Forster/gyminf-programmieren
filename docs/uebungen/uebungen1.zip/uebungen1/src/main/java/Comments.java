class Comments {

    /**
     * Entfernt alle Kommentare von dem übergebenen Java Programm.
     */
    public static String removeComments(String javaProgram) {
        // Ihre Implementation kommt hier hin

        return "";
    }

    public static void main(String[] args) {
        // Schreiben Sie hier Ihren eigenen Testcode
        
    }
}
