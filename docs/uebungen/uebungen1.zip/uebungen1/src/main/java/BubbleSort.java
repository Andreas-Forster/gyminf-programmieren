class BubbleSort {

    /**
     * Vertauscht zwei Werte in einem Array an den gegebenen Positionen.
     **/
    public static void swap(int i, int j, int[] a) {
        // Ihre Implementation kommt hier hin

    }

    /**
     * Sortiert das Eingabearray und Ändert das Array a so, dass die Elemente danach
     * aufsteigend sortiert sind.
     **/
    public static void sort(int[] a) {
        // Ihre Implementation kommt hier hin
        
    }

    /**
     * Schreibt das Array auf die Ausgabekonsole
     **/
    public static void displayArray(int[] a) {

        System.out.print("[");
        for (int i = 0; i < a.length - 1; i++) {
            System.out.print(a[i] + ", ");
        }

        if (a.length > 0) {
            System.out.print(a[a.length - 1]);
            System.out.println("]");
        }
    }

    /**
     * Die Hauptfunktion liest ein Array von den Kommandozeilenargumenten und ruft
     * die Sortierfunktion und die Ausgabefunktion auf
     **/
    public static void main(String[] args) {
        int[] a = new int[args.length];

        for (int i = 0; i < args.length; i++) {
            a[i] = Integer.parseInt(args[i]);
        }

        System.out.println("Array vor dem Sortieren");
        displayArray(a);

        sort(a);

        System.out.println("Array nach dem Sortieren");
        displayArray(a);
    }
}
