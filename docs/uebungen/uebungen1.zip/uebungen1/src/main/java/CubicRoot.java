public class CubicRoot { 

    public static void main(String[] args) {
        // Ihre Implementation kommt hier hin

    }

}