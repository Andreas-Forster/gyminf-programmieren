

public class CubicRoot { 


    public static void main(String[] args) {

        // Ihr Code kommt hierhin
        
    }
}