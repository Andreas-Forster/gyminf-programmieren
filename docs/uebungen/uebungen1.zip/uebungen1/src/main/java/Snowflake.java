import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import static ch.unibas.informatik.jturtle.TurtleCommands.*;

public class Snowflake {
  
  // Die maximale Rekursionstiefe 
  int depth = 0;

  // L?nge der Kochkurve
  static final int LENGTH_OF_CURVE = 120;

  /**
   * Kreiert eine Schneeflocke mit angegebener maximaler Rekursionstiefe
  */
  Snowflake(int depth) {
    clear();
    home();
    penColor(BLACK);
    this.depth = depth;
  }

  /**
   * Setzt das Turtle auf die Startposition
   */
  void setStartPosition() {
    penUp();
    home();
    forward(LENGTH_OF_CURVE * 0.3 );
    turnRight(90);
    backward(LENGTH_OF_CURVE * 0.5);
    penDown();
  }

  /** 
   * Zeichnet die Kochkurve auf dem aktuellen Rekursionslevel. 
   * Das Argument length gibt an wie lange ein Liniensegment sein soll
   */
  void drawKochCurve(int currentDepth, double length) {
    // Ihre Implementation kommt hier hin
    
  }


  /**
   * Zeichnet eine Scheeflocke, durch mehrmaliges zeichnen der Kochkurve
   */
  void drawSnowflake() {
    setStartPosition();

    // Ihre Implementation kommt hier hin

  }


  /**
   * Speichert das gezeichnete Bild.
   */
  void saveImage(String filename) {
    BufferedImage image = drawing();

    try {
      ImageIO.write(image, "png", new File(filename));
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }
  }

  /**
   * Testprogramm um Zeichnung mit verschiedenen Rekursionstiefen zu generieren. 
   */
  public static void main(String[] args) {

    // F?hrt das Programm f?r Rekursionstiefen 0 1 und 2 aus. 
    for (int i = 1; i <= 4; i++) {
      Snowflake flake = new Snowflake(i);
      flake.drawSnowflake();
      flake.saveImage("snowflake " + i + ".png");
    }
  }

}
