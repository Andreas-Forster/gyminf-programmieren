import java.io.IOException;

public class Palindrom  {

  /**
   * Gibt true zurück falls der übergeben String ein Palindrom ist.
   */
  public static boolean testPalindrom(String text) {
    // Ihre Implementation kommt hier hin

    return false;
  }


  public static void main(String[] args) throws IOException {
    // Hier kommt ihr eigener Testcode hin
    
  }

}