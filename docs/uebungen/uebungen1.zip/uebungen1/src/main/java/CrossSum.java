class CrossSum {



    public static void main(String[] args) {
        
        // Ihr Code kommt hierhin
        
    }
}
