class CrossSum {

    public static void main(String[] args) {
        // Ihre Implementation kommt hier hin

    }
    
}
