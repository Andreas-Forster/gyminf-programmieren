class styleMess {

    public static final int aconstant = 7;

    public static void AMethode(int anArgument)
    {
    double a_double_variable = 3.0;

    // Diese Methode macht eigentlich gar nichts sinnvolles, zeigt aber an, wie man am besten nicht programmieren würde.
    if (aconstant==3){
        System.out.println("Die Konstante ist 3");

    for(int I=0;I<10;++I) System.out.println("i ist"+I);
    }

    }

    public static void main(String[] args){
        
    }
}