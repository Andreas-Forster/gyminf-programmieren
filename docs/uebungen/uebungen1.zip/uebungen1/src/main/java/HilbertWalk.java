import static ch.unibas.informatik.jturtle.TurtleCommands.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class HilbertWalk {

  static final int BASE_LENGTH = 180;
  int depth = 0;
  double lengthLineSegment = 0;

  /**
   * Erzeugt ein neues Objekt HilbertWalk, welches die Hilbertkurve
   * mit angegebener Rekursionstiefe zeichnet.
   */
  HilbertWalk(int depth) {
    clear();
    home();
    penColor(BLACK);
    this.depth = depth;
    this.lengthLineSegment = computeLengthOfLineSegment();
  }


  /** 
   * Gibt die Länge eines Liniensegmentes in der Zeichnung zurück. 
   */
  double computeLengthOfLineSegment() {
    
    // In einem ersten Schritt nutzen Sie die fixe Länge von 6
    // Wenn ihr Code funktioniert, sollen Sie diese Methode so anpassen,
    // dass auf jeder Stufe die Zeichung die Länge BASE_LENGTH hat. 

    // Ihr Code
    
    return 6;
  }

  /**
   * Setzt das Turtle auf die Startposition
   */
  void setStartPosition() {
    penUp();
    home();
    backward(BASE_LENGTH / 2 );
    turnRight(90);
    forward(BASE_LENGTH / 2 );
    turnLeft(90);
    penDown();
  }

 
  /**
   * Zeichnet die Hilbertkurve
   */
  void drawHilbert() {
    setStartPosition();
    penDown();
    

    // Ihr Code

  }

  /**
   * Speichert die Kurve als png Bild unter angegebenem Dateinamen. 
   */
  void saveImage(String filename) {
    BufferedImage image = drawing();

    try {
      ImageIO.write(image, "png", new File(filename));
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }
  }

  public static void main(String[] args) {

    for (int i = 0; i < 5; i++) {
      HilbertWalk walk = new HilbertWalk(i);
      walk.drawHilbert();
      walk.saveImage("hilbert-" + i + ".png");
    }
  }

}
